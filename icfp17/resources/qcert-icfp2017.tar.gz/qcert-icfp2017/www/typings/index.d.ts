/// <reference path="globals/fabric/index.d.ts" />
