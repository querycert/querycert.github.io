/// <reference path="./typings/index.d.ts" />

declare var require: any;
declare var module: { id: string };