This directory is for top-level libraries
