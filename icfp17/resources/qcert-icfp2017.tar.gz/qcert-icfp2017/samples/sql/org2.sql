select name
from employees
where age > 32
;
